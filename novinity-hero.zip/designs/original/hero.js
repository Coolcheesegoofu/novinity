/* Novinity: video hero for the Original home design.
   The built app renders the home page into #root; this script watches for the
   Original hero (section.hh), puts the video hero in front of it, and hides it.
   It also adds the same prompt box to the "What should we write?" strip. */
(function () {
  'use strict';

  var script = document.currentScript;
  var BASE = new URL('../../', script ? script.src : location.href).pathname; // e.g. /novinity/
  var SCENE = BASE + 'designs/original/scenes/train/';
  var KEY = 'nvh-premise';

  var PREMISES = [
    'A lighthouse keeper finds letters from a sailor who drowned a hundred years ago.',
    'A heist aboard the last night train through the Alps.',
    'A cartographer is hired to map a town that isn’t on any map.',
    'Two rival botanists, one impossible flower, and a very long summer.',
    'A small-town detective, a missing church choir, and the coldest winter in fifty years.'
  ];

  var reduceMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var saveData = navigator.connection && navigator.connection.saveData;

  var ARROW = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">' +
    '<path d="M12 19V5M5.5 11.5 12 5l6.5 6.5" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  function el(tag, attrs, html) {
    var n = document.createElement(tag);
    if (attrs) for (var k in attrs) n.setAttribute(k, attrs[k]);
    if (html != null) n.innerHTML = html;
    return n;
  }

  /* ---------- navigation into the Create page ---------- */

  function goCreate(premise) {
    try { if (premise) sessionStorage.setItem(KEY, premise); } catch (e) {}
    var target = BASE + 'create';
    // Let the app's router handle it without a full page load.
    history.pushState(null, '', target);
    window.dispatchEvent(new PopStateEvent('popstate', { state: null }));
    window.scrollTo(0, 0);
    prefillCreate();
  }

  function prefillCreate() {
    var premise;
    try { premise = sessionStorage.getItem(KEY); } catch (e) {}
    if (!premise) return;
    var tries = 0;
    (function look() {
      var ta = document.querySelector('main textarea:not(.nvh-input)');
      if (ta && location.pathname.replace(/\/$/, '') === (BASE + 'create').replace(/\/$/, '')) {
        var setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
        setter.call(ta, premise);
        ta.dispatchEvent(new Event('input', { bubbles: true }));
        ta.focus();
        try { ta.setSelectionRange(premise.length, premise.length); } catch (e) {}
        try { sessionStorage.removeItem(KEY); } catch (e) {}
        return;
      }
      if (++tries < 60) setTimeout(look, 100);
    })();
  }

  /* ---------- prompt box ---------- */

  function promptBox(opts) {
    var id = 'nvh-input-' + opts.name;
    var form = el('form', { 'class': 'nvh-box' + (opts.cls ? ' ' + opts.cls : ''), novalidate: '' },
      '<label class="nvh-sr" for="' + id + '">Describe the novel you want to read</label>' +
      '<div class="nvh-field">' +
        '<div class="nvh-ghost" aria-hidden="true"></div>' +
        '<textarea class="nvh-input" id="' + id + '" rows="2" maxlength="600" autocomplete="off" spellcheck="true"></textarea>' +
      '</div>' +
      '<div class="nvh-foot">' +
        '<span class="nvh-hint">Press Enter to start your novel</span>' +
        '<button class="nvh-send" type="submit" aria-label="Start this novel">' + ARROW + '</button>' +
      '</div>');

    var ta = form.querySelector('textarea');
    var ghost = form.querySelector('.nvh-ghost');

    function sync() { form.classList.toggle('has-text', ta.value.trim().length > 0); }
    ta.addEventListener('input', sync);
    ta.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); form.requestSubmit ? form.requestSubmit() : submit(e); }
    });
    function submit(e) { if (e) e.preventDefault(); goCreate(ta.value.trim()); }
    form.addEventListener('submit', submit);

    if (opts.typing && !reduceMotion) typeLoop(ghost, form);
    else ghost.textContent = opts.placeholder || PREMISES[0];

    return form;
  }

  // Types example premises into the ghost placeholder, one after another.
  function typeLoop(ghost, form) {
    var i = 0, pos = 0, deleting = false;
    function tick() {
      if (!ghost.isConnected) return;
      if (form.classList.contains('has-text')) return setTimeout(tick, 400);
      var text = PREMISES[i];
      if (!deleting) {
        pos++;
        ghost.textContent = text.slice(0, pos);
        if (pos >= text.length) { deleting = true; return setTimeout(tick, 2600); }
        return setTimeout(tick, 34 + Math.random() * 40);
      }
      pos = Math.max(0, pos - 3);
      ghost.textContent = text.slice(0, pos);
      if (pos === 0) { deleting = false; i = (i + 1) % PREMISES.length; return setTimeout(tick, 350); }
      setTimeout(tick, 16);
    }
    setTimeout(tick, 700);
  }

  /* ---------- hero ---------- */

  function buildHero() {
    var hero = el('section', { 'class': 'nvh', 'aria-labelledby': 'nvh-title' });
    var media = el('div', { 'class': 'nvh-media', 'aria-hidden': 'true' });

    if (reduceMotion || saveData) {
      media.appendChild(el('img', { src: SCENE + 'poster.webp', alt: '', decoding: 'async', fetchpriority: 'high' }));
    } else {
      var small = window.matchMedia('(max-width: 900px)').matches;
      var v = el('video', { muted: '', loop: '', playsinline: '', autoplay: '', preload: 'auto', poster: SCENE + 'poster.webp' });
      v.muted = true; v.defaultMuted = true; v.playsInline = true;
      if (!small) v.appendChild(el('source', { src: SCENE + 'clip.webm', type: 'video/webm' }));
      v.appendChild(el('source', { src: SCENE + (small ? 'clip-1280.mp4' : 'clip.mp4'), type: 'video/mp4' }));
      media.appendChild(v);
      // Pause when the hero is off screen.
      if ('IntersectionObserver' in window) {
        new IntersectionObserver(function (entries) {
          entries.forEach(function (en) {
            if (en.isIntersecting) { var p = v.play(); if (p && p.catch) p.catch(function () {}); }
            else v.pause();
          });
        }, { threshold: 0.05 }).observe(hero);
      }
    }

    var copy = el('div', { 'class': 'nvh-copy' });
    copy.appendChild(el('h1', { 'class': 'nvh-title', id: 'nvh-title' }, 'One sentence. A&nbsp;whole&nbsp;novel.'));
    copy.appendChild(el('p', { 'class': 'nvh-sub' }, 'Tell us the book you’ve always wanted to read. We write it, typeset it and design its cover.'));
    copy.appendChild(promptBox({ name: 'hero', typing: true }));
    copy.appendChild(el('a', { 'class': 'nvh-alt', href: BASE + 'read/quiet-frequency', 'data-nvh-link': '' }, 'Or read a sample first'));

    hero.appendChild(media);
    hero.appendChild(el('div', { 'class': 'nvh-scrim', 'aria-hidden': 'true' }));
    hero.appendChild(copy);
    return hero;
  }

  // Internal links inside our markup go through the app router too.
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[data-nvh-link]');
    if (!a || e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
    e.preventDefault();
    history.pushState(null, '', a.getAttribute('href'));
    window.dispatchEvent(new PopStateEvent('popstate', { state: null }));
    window.scrollTo(0, 0);
  });

  /* ---------- mounting ---------- */

  function mount() {
    var hh = document.querySelector('section.hh');
    var on = !!hh;
    if (hh && !(hh.previousElementSibling && hh.previousElementSibling.classList.contains('nvh'))) {
      var old = document.querySelector('.nvh');
      if (old) old.remove();
      hh.parentNode.insertBefore(buildHero(), hh);
    }
    document.documentElement.classList.toggle('nvh-on', on);

    var strip = on && document.querySelector('.tile--strip .tile-copy');
    if (strip && !strip.querySelector('.nvh-box')) {
      strip.appendChild(promptBox({ name: 'strip', cls: 'nvh-box--strip', placeholder: 'Describe the novel you want to read…' }));
    }
  }

  var queued = false;
  new MutationObserver(function (records) {
    // Ignore changes inside our own markup (the typing placeholder, mostly).
    var outside = records.some(function (r) { return !(r.target.closest && r.target.closest('.nvh, .nvh-box')); });
    if (!outside || queued) return;
    queued = true;
    // Run before the next paint so the old hero never flashes.
    (window.queueMicrotask || setTimeout)(function () { queued = false; mount(); });
  }).observe(document.documentElement, { childList: true, subtree: true });

  mount();
  prefillCreate();
})();
